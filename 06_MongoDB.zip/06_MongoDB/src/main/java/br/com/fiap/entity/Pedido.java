package br.com.fiap.entity;

import java.sql.Date;
import java.util.List;

import org.springframework.data.annotation.Id;

public class Pedido {
	
	@Id
	private String id;
	private String dataPedido;
	private List<Produto> produto; 
	
	@Override
	public String toString() {
		return "Pedido [dataPedido=" + dataPedido + ", produto=" + produto + "]";
	}
	
	public Pedido() {
		super();
	}
	
	public Pedido(String dataPedido, List<Produto> produto) {
		super();
		this.dataPedido = dataPedido;
		this.produto    = produto;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDataPedido() {
		return dataPedido;
	}

	public void setDataPedido(String dataPedido) {
		this.dataPedido = dataPedido;
	}

	public List<Produto> getProduto() {
		return produto;
	}

	public void setProduto(List<Produto> produto) {
		this.produto = produto;
	}
	
}
