package br.com.fiap.application;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Sort;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import br.com.fiap.entity.Endereco;
import br.com.fiap.entity.Pedido;
import br.com.fiap.entity.Pessoa;
import br.com.fiap.entity.Produto;
import br.com.fiap.repository.PessoaRepository;

@SpringBootApplication
@EnableMongoRepositories(basePackageClasses = PessoaRepository.class)
public class Application implements CommandLineRunner {

	@Autowired
	public PessoaRepository repository;
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		repository.deleteAll();
		
		repository.save(new Pessoa("Silvia", 27));
		repository.save(new Pessoa("Silvia", 22));
		
		Endereco residencial = new Endereco("Rua Jose Caetano", "SP");
		Endereco comercial = new Endereco("Avenida Silva Santos", "SP");
		List<Endereco> enderecos = new ArrayList<>();
		enderecos.add(residencial);
		enderecos.add(comercial);

		Produto produto_1 		= new Produto("Mouse", 150, 1);
		Produto produto_2       = new Produto("Teclado", 250, 1);
		List<Produto> produtos  = new ArrayList<>();
		produtos.add(produto_1);
		produtos.add(produto_2);
		
		Pedido pedido_1     = new Pedido("20.04.2022", produtos);
		Pedido pedido_2     = new Pedido("20.04.2022", produtos);
		List<Pedido> pedidos = new ArrayList<>();
		pedidos.add(pedido_1);
		pedidos.add(pedido_2);
		
		repository.save(new Pessoa("Paulo Silva", 45, enderecos, pedidos));
		repository.save(new Pessoa("Pamela Brito", 60, enderecos, pedidos));
		repository.save(new Pessoa("Julia Goncalves", 30, enderecos, pedidos));
		
		Endereco rj = new Endereco("Rua João Caxias", "RJ");
		List<Endereco> ends = new ArrayList<>();
		ends.add(rj);
		
		// find all
		System.out.println("Documents found with findAll():");
		System.out.println("-------------------------------");
		for (Pessoa pessoa : repository.findAll()) {
			System.out.println(pessoa);
		}
		System.out.println("\n");
		
		// find by nome
		System.out.println("Documents found with findByNome('Silvia'):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByNome("Silvia"));
		System.out.println("\n");
		
		// find by nome using like
		System.out.println("Documents found with findByNomeLike('Pa'):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByNomeLike("Pa"));
		System.out.println("\n");
		
		// find by idade
		System.out.println("Documents found with findByIdade(30):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByIdade(30));
		System.out.println("\n");
		
		// find by idade between
		System.out.println("Documents found with findByIdadeBetween(25,35):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByIdadeBetween(25,35));
		System.out.println("\n");
		
		// find by regexp nome
		System.out.println("Documents found with findByRegexpNome(\"^Silv\"):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByRegexpNome("^Silv"));
		System.out.println("\n");
		
		// find by regexp nome and order by idade
		System.out.println("Documents found with findByRegexpNomeOrderByIdade('^Silv'):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByRegexpNomeOrderByIdade("^Silv"));
		System.out.println("\n");

		// count by name
		System.out.println("Documents found with countByName(\"Silvia\"):");
		System.out.println("--------------------------------");
		System.out.println(repository.countByName("Silvia"));
		System.out.println("\n");
		
		// find by cidade
		System.out.println("Documents found with findByCidade(\"RJ\"):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByCidade("SP"));
		System.out.println("\n");
		
		
	}
}
